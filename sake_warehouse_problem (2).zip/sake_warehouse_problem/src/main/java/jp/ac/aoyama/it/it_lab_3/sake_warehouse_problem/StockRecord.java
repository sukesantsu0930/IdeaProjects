//15822065 助友剛
package jp.ac.aoyama.it.it_lab_3.sake_warehouse_problem;

public class StockRecord {
    private String brand;
    private int numberOfBottles;

    public StockRecord(String brand,int numberOfBottles){
        this.brand=brand;
        this.numberOfBottles=numberOfBottles;

    }

    public String getBrand(){
        return brand;
    }

    public int getNumberOfBottles(){
        return numberOfBottles;
    }

    public void setNumberOfBottles(int numberOfBottles){
        this.numberOfBottles=numberOfBottles;
    }






}