//15822065 助友剛

package jp.ac.aoyama.it.it_lab_3.sake_warehouse_problem;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;


public class Tag {

    // フィールドの宣言
    private Container container;
    private String broughtDate;
    private List<StockRecord> stockRecordList;

    // コンストラクタ
    public Tag(Container container) {
        this.container = container;
        this.stockRecordList = new ArrayList<>();
        this.broughtDate = new SimpleDateFormat("yyyy-MM-dd").format(new Date()); // 現在の日付をデフォルトで設定
    }

    // メソッドの宣言
    public void addStockRecord(StockRecord stockRecord) {
        stockRecordList.add(stockRecord);
    }

    public String getBroughtDate() {
        return broughtDate.toString();
    }

    public void setBroughtDate(Date broughtDate) {
        this.broughtDate = new SimpleDateFormat("yyyy-MM-dd").format(broughtDate);
    }

    public Container getContainer() {
        return container;
    }

    public int getContainerId() {
        return container.getId();
    }

    public List<StockRecord> getStockRecordList() {
        return stockRecordList;
    }

    public int takeLiquor(String liquorBrand, int quantityRequested) {
        int totalBottlesTaken = quantityRequested;
        List<StockRecord> emptyRecords = new ArrayList<>();

        // 在庫リストをループして、指定したブランドのボトルを取り出す
        for (StockRecord record : stockRecordList) {
            if (record.getBrand().equals(liquorBrand) && quantityRequested > 0) {
                int availableBottles = record.getNumberOfBottles();

                // 取り出すべきボトル数が在庫より多い場合
                if (availableBottles >= quantityRequested) {
                    record.setNumberOfBottles(availableBottles - quantityRequested);
                    quantityRequested = 0; // 必要な数を取り出したので終了

                    // 在庫が空になったレコードをリストに追加
                    if (record.getNumberOfBottles() == 0) {
                        emptyRecords.add(record);
                    }
                    break; // 取り出しが完了したので終了
                } else {
                    // 在庫が足りない場合、可能なだけ取り出す
                    quantityRequested -= availableBottles;
                    record.setNumberOfBottles(0); // 在庫を空にする

                    // 空になったレコードをリストに追加
                    emptyRecords.add(record);
                }
            }
        }

        // 空になったレコードを在庫リストから削除
        stockRecordList.removeAll(emptyRecords);

        // 実際に取り出したボトル数を返す
        return totalBottlesTaken - quantityRequested;
    }

}