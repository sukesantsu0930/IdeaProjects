//15822065 助友剛
package jp.ac.aoyama.it.it_lab_3.sake_warehouse_problem;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class Container {

    // 定数フィールド
    public static final int NUM_OF_MAX_CONTAINERS = 6; // 仮の最大コンテナ数

    // フィールドの宣言
    private int id;
    private List<StockUnit> stockList;
    private Tag tag;
    int total = 0;

    // コンストラクタ
    public Container(int id) {
        this.id = id;
        stockList = new ArrayList<>();

        tag = new Tag(this);
    }

    // メソッドの宣言
    public void carryOut() {
        // メソッドの内容
    }

    public int getId() {
        // メソッドの内容
        return 0;
    }

    public List<StockUnit> getStockList() {
        // メソッドの内容
        return stockList;
    }

    public Tag getTag() {
        // メソッドの内容

        return tag;
    }

    public int getTotalNumberOfBottles() {
        // メソッドの内容

        for (StockUnit stockunit : stockList) {
            total += stockunit.getNumberOfBottles();
        }

        return total;
    }

    public void putLiquor(Liquor liquor, int numOfBottles) {
        // メソッドの内容
        StockUnit stockunit;
        try {
            stockunit = new StockUnit(liquor, numOfBottles);
        } catch (Exception e) {
            throw new RuntimeException("ボトル数が最大許容量を超えています。", e);
        }

        stockList.add(stockunit);
        //System.out.println("Added " + numOfBottles + " bottles of " + liquor.getBrand());
        tag.addStockRecord(new StockRecord(stockunit.getBrand(), stockunit.getNumberOfBottles()));

    }


    public int takeLiquor(String liquorBrand, int quantityToTake) {
        int totalBottlesTaken = 0;
        List<StockUnit> emptyUnits = new ArrayList<>();
        System.out.println("Attempting to take " + quantityToTake + " bottles of " + liquorBrand);

        // 在庫リストの中で、指定されたブランドと数量をチェック
        for (StockUnit unit : stockList) {
            if (unit.getBrand().equals(liquorBrand) && quantityToTake > 0) {
                System.out.println("Processing stock unit: " + unit.getBrand() + ", Available bottles: " + unit.getNumberOfBottles());

                // 取り出すべきボトル数が現在の在庫数より少ない場合
                if (unit.getNumberOfBottles() > quantityToTake) {
                    unit.setNumberOfBottles(unit.getNumberOfBottles() - quantityToTake);
                    System.out.println("Took " + quantityToTake + " bottles. Remaining stock: " + unit.getNumberOfBottles());
                    totalBottlesTaken += quantityToTake;
                    quantityToTake = 0; // 取り出しが完了
                    break; // 必要な数が満たされたのでループ終了
                } else {
                    // 在庫が足りない場合、現在の在庫を全て取り出す
                    totalBottlesTaken += unit.getNumberOfBottles();
                    quantityToTake -= unit.getNumberOfBottles();
                    System.out.println("Took " + unit.getNumberOfBottles() + " bottles. Remaining bottles to take: " + quantityToTake);
                    unit.setNumberOfBottles(0); // 在庫を空にする
                    emptyUnits.add(unit); // 空になったユニットはリストから削除対象
                }
            }
        }

        // 空のユニットは在庫リストから削除
        stockList.removeAll(emptyUnits);
        System.out.println("Final stock list size: " + stockList.size());

        // 取り出したボトルの数を返す
        return totalBottlesTaken;
    }








}