//15822065 助友剛

package jp.ac.aoyama.it.it_lab_3.sake_warehouse_problem;

import java.util.ArrayList;
import java.util.List;

public class WarehouseKeeper {
    // 出庫依頼リストを保存するファイル名
    public static final String REQUEST_LIST_FILE_PATH = "request_list.txt";

    private WarehouseClerk warehouseClerk;
    private List<Container> containers;

    // 倉庫係クラスのデフォルトコンストラクタ
    public WarehouseKeeper() {

        this.containers = new ArrayList<>();
    }


    public void bringContainers(Container container) throws Exception {
        // コンテナ数の上限を超えていないかチェック
        if (containers.size() >= Container.NUM_OF_MAX_CONTAINERS) {
            throw new Exception("倉庫にこれ以上コンテナを搬入できません。");
        }

        // コンテナを倉庫に格納
        containers.add(container);

        // 受付係に積荷票を渡す
        warehouseClerk.addTag(container);

        System.out.println("コンテナ " + container + " を倉庫に搬入しました。");
    }


    public int getNumberOfContainers() {

        return containers.size();
    }


    public void setWarehouseClerk(WarehouseClerk warehouseClerk) {
        this.warehouseClerk = warehouseClerk;
    }
    public void shipLiquors(List<RequestRecord> requestList) throws Exception {
        // 出庫指示を処理
        for (RequestRecord request : requestList) {
            // 出庫指示のコンテナを取得
            Container container = request.getContainer();

            // コンテナが倉庫に存在するかチェック
            if (!containers.contains(container)) {
                throw new Exception("指定されたコンテナは倉庫に存在しません: " + container);
            }

            // 出庫指示に基づいて酒を出庫
            String liquorBrand = request.getBrand();
            int quantity = request.getNumberOfBottles();
            int bottlesShipped = container.takeLiquor(liquorBrand, quantity);

            // 出庫したボトル数がゼロになった場合、コンテナを倉庫から削除
            if (container.getTotalNumberOfBottles() == 0) {
                containers.remove(container);
                System.out.println("コンテナ " + container + " は空になったため倉庫から搬出されました。");
            }

            // 受付係の積荷票から削除
            warehouseClerk.removeTag(request);
            System.out.println("出庫指示に従ってコンテナ " + container + " から " + bottlesShipped + " 本の酒を出庫しました。");
        }
    }

}
