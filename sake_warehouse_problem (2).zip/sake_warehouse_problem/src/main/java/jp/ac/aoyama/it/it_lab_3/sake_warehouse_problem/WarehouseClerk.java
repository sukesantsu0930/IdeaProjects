//15822065 助友剛

package jp.ac.aoyama.it.it_lab_3.sake_warehouse_problem;

import java.util.ArrayList;
import java.util.List;

public class WarehouseClerk {
    // フィールド
    static final String NEW_STOCK_LIST_FILE_PATH = "new_stock_list.txt"; // 出庫後の在庫リストを保存するファイル名
    static String OUT_OF_STOCK_LIST_FILE_PATH = "out_of_stock_list.txt"; // 在庫不足リストを保存するファイル名
    static String STOCK_LIST_FILE_PATH = "stock_list.txt"; // 在庫リストを保存するファイル名

    private List<Tag> tagList; // 管理している積荷票リスト
    private WarehouseKeeper warehouseKeeper; // ウェアハウスキーパーのインスタンス

    // コンストラクタ
    public WarehouseClerk(WarehouseKeeper warehouseKeeper) {
        this.warehouseKeeper = warehouseKeeper;
        this.tagList = new ArrayList<>(); // 積荷票リストの初期化
    }

    public WarehouseClerk() {

    }

    // メソッド: 積荷票を受け取り，管理している積荷票リストに加える
    public void addTag(Tag tag) {
        tagList.add(tag);
    }

    // メソッド: 積荷票リストを返す
    public List<Tag> getTagList() {
        return tagList;
    }

    // メソッド: 出庫依頼を受けて，在庫確認と出庫指示を行う
    public boolean makeRequest(Order order) {
        // 在庫確認と出庫指示のロジックを実装する
        return true; // 仮に成功した場合
    }

    // メソッド: 在庫不足リストをファイルに出力する
    public void reportOutOfStockBottles(Order order, int numOfOutOfStockBottles) {
        // 在庫不足リストをファイルに出力するロジックを実装する
    }

    // メソッド: 現在の在庫リストをファイルに出力する
    public void writeStockList(String stockListFilePath) {
        // 在庫リストをファイルに出力するロジックを実装する
    }
}
