//15822065 助友剛
package jp.ac.aoyama.it.it_lab_3.sake_warehouse_problem;



public class StockUnit {

    // フィールドの宣言
    private Liquor liquor;
    private int numberOfBottles;
    public static final int NUM_OF_MAX_BOTTLES=100;

    // コンストラクタ
    public StockUnit(Liquor liquor, int numberOfBottles) throws Exception {
        // コンストラクタの内容
        if (numberOfBottles > NUM_OF_MAX_BOTTLES) {
            throw new Exception("ボトル数が最大許容量を超えています。");
        }
        this.liquor= liquor;
        this.numberOfBottles = numberOfBottles;
    }

    // メソッドの宣言
    public String getBrand() {
        // メソッドの内容
        return liquor.getBrand();
    }

    public int getNumberOfBottles() {
        // メソッドの内容
        return numberOfBottles;
    }

    public void setNumberOfBottles(int numberOfBottles) {
        // メソッドの内容
        this.numberOfBottles=numberOfBottles;
    }


}