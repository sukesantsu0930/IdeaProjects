package pocket;

public class StringPocket {
	private String data;

	public void put(String d) {
		this.data = d;
	}

	public String get() {
		return this.data;
	}
}
