package jp.ac.aoyama.it.it_lab_3.demo;


import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc
public class HelloControllerTests {

    @Autowired
    private MockMvc mockMvc;

    @Test
    public void testHelloController1() throws Exception {
        this.mockMvc.perform(get("/template_test"))
                .andExpect(status().isOk())
                .andExpect(view().name("index"))
                .andExpect(xpath("/html/body/h1").string("Hello, Template Engine!"));
    }

    @Test
    public void testHelloController2() throws Exception {
        this.mockMvc.perform(get("/text_field_test_input"))
                .andExpect(status().isOk())
                .andExpect(view().name("text_field_test_input"))
                .andExpect(xpath("/html/body/form/@action").string("/text_field_test_output"));
    }

    @Test
    public void testHelloController3() throws Exception {
        this.mockMvc.perform(post("/text_field_test_output").param("text1", "青山"))
                .andExpect(status().isOk())
                .andExpect(view().name("index"))
                .andExpect(xpath("/html/body/h1").string("こんにちは、青山さん"));
    }

    @Test
    public void testHelloController4() throws Exception {
        this.mockMvc.perform(get("/form_test_input"))
                .andExpect(status().isOk())
                .andExpect(view().name("form_test_input"))
                .andExpect(xpath("/html/body/form/@action").string("/form_test_output"));
    }

    @Test
    public void testHelloController5() throws Exception {
        this.mockMvc.perform(post("/form_test_output").param("check1", "true").param("travel_category", "domestic").param("job_title", "professor"))
                .andExpect(status().isOk())
                .andExpect(view().name("form_test_output"))
                .andExpect(xpath("//table/tr[1]/td").string("true"))
                .andExpect(xpath("//table/tr[2]/td").string("domestic"))
                .andExpect(xpath("//table/tr[3]/td").string("professor"));
    }

}
