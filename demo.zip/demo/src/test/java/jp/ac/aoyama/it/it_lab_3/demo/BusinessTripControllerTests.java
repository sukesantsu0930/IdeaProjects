package jp.ac.aoyama.it.it_lab_3.demo;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc
public class BusinessTripControllerTests {

    @Autowired
    private MockMvc mockMvc;

    @Test
    public void testBusinessTripController1() throws Exception {
        this.mockMvc.perform(get("/business_trip_input"))
                .andExpect(status().isOk())
                .andExpect(view().name("business_trip_input"))
                .andExpect(xpath("/html/body/form/@action").string("/business_trip_output"))
                .andExpect(xpath("/html/body/form/div[2]/label").string("出張時間"))
                .andExpect(xpath("/html/body/form/div[2]/label/@for").string("travel_hours"))
                .andExpect(xpath("/html/body/form/div[2]/input/@type").string("text"))
                .andExpect(xpath("/html/body/form/div[2]/input/@id").string("travel_hours"))
                .andExpect(xpath("/html/body/form/div[2]/input/@name").string("travel_hours"));
    }

    private void testBusinessTripOutput(String travelHours, String expectedDailyAllowance) throws Exception {
        this.mockMvc.perform(post("/business_trip_output")
                        .param("name", "青山太郎")
                        .param("travel_hours", travelHours))
                .andExpect(status().isOk())
                .andExpect(view().name("business_trip_output"))
                .andExpect(xpath("//table/tr[1]/td").string("青山太郎"))
                .andExpect(xpath("//table/tr[2]/td").string(travelHours))
                .andExpect(xpath("//table/tr[3]/td").string(expectedDailyAllowance));
    }

    @Test
    public void testBusinessTripController2() throws Exception {
        testBusinessTripOutput("3", "0");
    }

    @Test
    public void testBusinessTripController3() throws Exception {
        testBusinessTripOutput("5", "1000");
    }


    @Test
    public void testBusinessTripController4() throws Exception {
        testBusinessTripOutput("9", "2000");
    }

    @Test
    public void testBusinessTripController5() throws Exception {
        testBusinessTripOutput("12", "3000");
    }
}
