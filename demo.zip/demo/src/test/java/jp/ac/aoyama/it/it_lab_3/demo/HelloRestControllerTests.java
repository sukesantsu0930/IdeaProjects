package jp.ac.aoyama.it.it_lab_3.demo;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.servlet.MockMvc;

import java.nio.charset.StandardCharsets;

import static org.hamcrest.Matchers.containsString;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
public class HelloRestControllerTests {
    @Autowired
    private MockMvc mockMvc;

    @Test
    public void testHelloRestController1() throws Exception {
        this.mockMvc.perform(get("/")).andDo(print()).andExpect(status().isOk())
                .andExpect(content().string(containsString("Hello Spring-Boot World!!")));
    }

    @Test
    public void testHelloRestController2() throws Exception {
        String responseJsonString = this.mockMvc.perform(get("/data_object")).andDo(print()).andExpect(status().isOk())
                .andReturn().getResponse().getContentAsString(StandardCharsets.UTF_8);
        ObjectMapper objectMapper = new ObjectMapper();
        DataObject actualDataObj = objectMapper.readValue(responseJsonString, DataObject.class);
        DataObject expectedDataObj = new DataObject("山田太郎", 10);
        Assertions.assertThat(actualDataObj.getName()).isEqualTo(expectedDataObj.getName());
        Assertions.assertThat(actualDataObj.getTravelHours()).isEqualTo(expectedDataObj.getTravelHours());
    }

}
