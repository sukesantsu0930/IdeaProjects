//15822065 助友剛

package jp.ac.aoyama.it.it_lab_3.demo;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class HelloController {
    @GetMapping("/template_test")
    public String templateTest(Model model){
        model.addAttribute("msg","Hello, Template Engine!");
        return "index";
    }

    @GetMapping("/text_field_test_input")
    public String textFieldTestInput(Model model){
        return "text_field_test_input";
    }

    @PostMapping("/text_field_test_output")
    public String textFieldTestOutput(@RequestParam("text1") String text1, Model model){
        model.addAttribute("msg","こんにちは、"+text1+"さん");
        return "index";
    }

    @GetMapping("/form_test_input")
    public String formTestInput(){
        return "form_test_input";
    }

    @PostMapping("/form_test_output")
    public String formTestOutput(@RequestParam(value="check1",required = false) boolean isChecked,
                                 @RequestParam(value = "travel_category") String travelCategory,
                                 @RequestParam(value = "job_title") String jobTitle,
                                 Model model){
        model.addAttribute("is_checked",isChecked);
        model.addAttribute("travel_category",travelCategory);
        model.addAttribute("job_title",jobTitle);
        return "form_test_output";

    }


}
