//15822065 助友剛

package jp.ac.aoyama.it.it_lab_3.demo;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HelloRestController {
    @GetMapping("/")
    public String index(){
        return "Hello Spring-Boot World!!";
    }

    @GetMapping("/data_object")
    public DataObject getDataObject(){
        DataObject btm=new DataObject("山田太郎",10);
        return btm;
    }
}
