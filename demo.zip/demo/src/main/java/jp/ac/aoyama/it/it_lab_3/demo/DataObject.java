//15822065 助友剛

package jp.ac.aoyama.it.it_lab_3.demo;

public class DataObject {
    private String name;
    private int travelHours;

    public DataObject(){

    }

    public DataObject(String name,int travelHours){
        this.name=name;
        this.travelHours=travelHours;
    }

    public String getName(){
        return name;
    }

    public void setName(String name){
        this.name=name;
    }

    public int getTravelHours(){
        return travelHours;
    }

    public void setTravelHours(int travelHours){
        this.travelHours=travelHours;
    }
}
