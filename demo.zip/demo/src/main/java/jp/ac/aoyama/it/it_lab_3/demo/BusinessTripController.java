//15822065 助友剛

package jp.ac.aoyama.it.it_lab_3.demo;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class BusinessTripController {

    @GetMapping("/business_trip_input")
    public String textFieldTestInput(Model model){
        return "business_trip_input";
    }

    @PostMapping("/business_trip_output")
    public String textFieldTestOutput(@RequestParam("name") String name,
                                      @RequestParam("travel_hours") int travelHours,
                                      Model model){
        int allowance;
        if(travelHours<5){
            allowance=0;
        }else if(travelHours<9){
            allowance=1000;
        }else if(travelHours<12){
            allowance=2000;
        }else{
            allowance=3000;
        }

        model.addAttribute("name",name);
        model.addAttribute("travel_hours",travelHours);
        model.addAttribute("allowance",allowance);
        return "business_trip_output";
    }
}