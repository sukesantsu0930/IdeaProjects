package jp.ac.aoyama.it.it_lab_3.bts_sample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BtsSampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
