package jp.ac.aoyama.it.it_lab_3.bts_sample;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BtsSampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(BtsSampleApplication.class, args);
	}

}
