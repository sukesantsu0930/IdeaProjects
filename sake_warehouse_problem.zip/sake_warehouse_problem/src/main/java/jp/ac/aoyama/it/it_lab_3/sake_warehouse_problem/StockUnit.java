//15822065 助友剛

package jp.ac.aoyama.it.it_lab_3.sake_warehouse_problem;

public class StockUnit {
    public static final int NUM_OF_MAX_BOTTLES = 20;  // 最大ボトル数
    private Liquor liquorName;  // 酒の銘柄
    private int numberOfBottles; // 現在のボトル数

    // コンストラクタ（ボトル数の上限チェック付き）
    public StockUnit(Liquor liquorName, int numberOfBottles) {
        this.liquorName = liquorName;
        if (numberOfBottles > NUM_OF_MAX_BOTTLES) {
            throw new IllegalArgumentException("ボトル数が最大数を超えています。");
        }
        this.numberOfBottles = numberOfBottles;
    }

    // getterとsetter
    public Liquor getLiquorName() {
        return liquorName;
    }

    public void setLiquorName(Liquor liquorName) {
        this.liquorName = liquorName;
    }

    public int getNumberOfBottles() {
        return numberOfBottles;
    }

    public void setNumberOfBottles(int numberOfBottles) {
        if (numberOfBottles > NUM_OF_MAX_BOTTLES) {
            throw new IllegalArgumentException("ボトル数が最大数を超えています。");
        }
        this.numberOfBottles = numberOfBottles;
    }

    // toStringメソッド
    @Override
    public String toString() {
        return "StockUnit{liquorName='" + liquorName + "', numberOfBottles=" + numberOfBottles + '}';
    }
}
