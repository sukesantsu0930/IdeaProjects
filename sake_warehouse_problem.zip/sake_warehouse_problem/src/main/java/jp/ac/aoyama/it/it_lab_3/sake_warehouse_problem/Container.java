package jp.ac.aoyama.it.it_lab_3.sake_warehouse_problem;

import java.util.ArrayList;
import java.util.List;

public class Container {
    public static final int NUM_OF_MAX_CONTAINERS = 6; // 最大コンテナ数
    private int id; // コンテナID
    private List<Tag> tags; // コンテナ内の積荷票リスト

    public Container(int id) {
        this.id = id;
        this.tags = new ArrayList<>();
    }

    public void putLiquor(Liquor liquor, int numOfBottles) {
        Tag tag = findOrCreateTag(liquor);
        tag.addStock(numOfBottles);
    }

    private Tag findOrCreateTag(Liquor liquor) {
        for (Tag tag : tags) {
            if (tag.getLiquor().getBrand().equals(liquor.getBrand())) {
                return tag;
            }
        }
        Tag newTag = new Tag(liquor, 0);
        tags.add(newTag);
        return newTag;
    }

    public int takeLiquor(String liquorName, int quantity) {
        int totalTaken = 0;
        for (int i = 0; i < tags.size(); i++) {
            Tag tag = tags.get(i);
            totalTaken += tag.takeLiquor(liquorName, quantity - totalTaken);

            // タグが空になったら削除
            if (tag.getNumberOfBottles() == 0) {
                tags.remove(i);
                i--; // 削除後のインデックス調整
            }

            if (totalTaken >= quantity) {
                break;
            }
        }
        return totalTaken;
    }

    public int getId() {
        return id;
    }


    public int getTotalNumberOfBottles() {
        int total = 0;
        for (Tag tag : tags) {
            total += tag.getNumberOfBottles();
        }
        return total;
    }

    public void carryOut() {
        System.out.printf("コンテナ番号=%dのコンテナは空になったため、搬出されました。\n", id);
    }
    public Tag getTag() {
        return tags.isEmpty() ? null : tags.get(0);
    }
    public List<Tag> getStockList() {
        return tags;
    }


    @Override
    public String toString() {
        return "Container{id=" + id + ", totalBottles=" + getTotalNumberOfBottles() + ", tags=" + tags + '}';
    }


}
