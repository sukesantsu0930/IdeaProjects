package jp.ac.aoyama.it.it_lab_3.sake_warehouse_problem;

public class Liquor {
    private String brand; // 酒の銘柄
    private int quantity; // 在庫数

    public Liquor(String brand, int quantity) {
        this.brand = brand;
        this.quantity = quantity;
    }

    public Liquor(String brand) {
        this(brand, 0); // 初期数量を0に設定
    }

    public String getBrand() {
        return brand;
    }

    @Override
    public String toString() {
        return "Liquor{brand='" + brand + "', quantity=" + quantity + '}';
    }
}
