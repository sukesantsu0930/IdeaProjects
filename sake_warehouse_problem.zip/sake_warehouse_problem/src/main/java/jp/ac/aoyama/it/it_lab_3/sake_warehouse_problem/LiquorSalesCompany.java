//15822065 助友剛

package jp.ac.aoyama.it.it_lab_3.sake_warehouse_problem;

public class LiquorSalesCompany {

    // デフォルトコンストラクタ
    public LiquorSalesCompany() {
        // ここに初期化コードを追加できます
    }

    // 倉庫係を返すメソッド
    public WarehouseKeeper getWarehouseKeeper() {
        // 仮の実装: 倉庫係を生成して返す
        return new WarehouseKeeper();
    }

    // 受付係を返すメソッド
    public WarehouseClerk getWarehouseClerk() {
        // 仮の実装: 受付係を生成して返す
        return new WarehouseClerk();
    }

    // その他のメソッドやフィールドを追加することもできます
}
