//15822065 助友剛

package jp.ac.aoyama.it.it_lab_3.sake_warehouse_problem;

public class RequestRecord {
    private Container container; // コンテナ
    private String orderId; // 注文番号
    private String sendingCustomerName; // 送り先名
    private String brand; // 酒の銘柄
    private int numberOfBottles; // ボトルの本数

    // コンストラクタ
    public RequestRecord(Container container, String orderId, String sendingCustomerName, String brand, int numberOfBottles) {
        this.container = container;
        this.orderId = orderId;
        this.sendingCustomerName = sendingCustomerName;
        this.brand = brand;
        this.numberOfBottles = numberOfBottles;
    }

    // コンテナを返すメソッド
    public Container getContainer() {
        return container;
    }

    // 酒の銘柄を返すメソッド
    public String getBrand() {
        return brand;
    }

    // ボトルの本数を返すメソッド
    public int getNumberOfBottles() {
        return numberOfBottles;
    }

    // 出庫指示書の1行分を返すメソッド
    @Override
    public String toString() {
        return "Order ID: " + orderId + ", Container: " + container.getId() +
                ", Customer Name: " + sendingCustomerName + ", Brand: " + brand +
                ", Number of Bottles: " + numberOfBottles;
    }
}
