//15822065 助友剛

package jp.ac.aoyama.it.it_lab_3.sake_warehouse_problem;

import java.util.ArrayList;
import java.util.List;

public class WarehouseKeeper {
    // 出庫依頼リストを保存するファイル名
    public static final String REQUEST_LIST_FILE_PATH = "request_list.txt";

    private WarehouseClerk warehouseClerk;
    private List<Container> containers;

    // 倉庫係クラスのデフォルトコンストラクタ
    public WarehouseKeeper() {
        this.containers = new ArrayList<>();
    }


    public void bringContainers(Container container) {
        containers.add(container);
        // ここに受付係に積荷票を渡す処理を追加
    }

    public int getNumberOfContainers() {
        return containers.size();
    }


    public void setWarehouseClerk(WarehouseClerk warehouseClerk) {
        this.warehouseClerk = warehouseClerk;
    }

    public void shipLiquors(List<RequestRecord> requestList) {
        for (RequestRecord request : requestList) {
            // 出庫指示に従った処理を実装
        }
    }
}
