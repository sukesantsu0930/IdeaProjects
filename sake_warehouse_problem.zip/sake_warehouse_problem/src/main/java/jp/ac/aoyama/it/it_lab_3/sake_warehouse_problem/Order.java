//15822065 助友剛

package jp.ac.aoyama.it.it_lab_3.sake_warehouse_problem;

public class Order {
    // フィールド
    private String orderId;              // 注文番号
    private String brand;                 // 酒の銘柄
    private int numberOfBottles;         // ボトルの本数
    private String sendingCustomerName;   // 送り先名


    public Order(String orderId, String brand, int numberOfBottles, String sendingCustomerName) {
        this.orderId = orderId;
        this.brand = brand;
        this.numberOfBottles = numberOfBottles;
        this.sendingCustomerName = sendingCustomerName;
    }


    public String getOrderId() {
        return orderId;
    }

    public String getBrand() {
        return brand;
    }


    public int getNumberOfBottles() {
        return numberOfBottles;
    }


    public String getSendingCustomerName() {
        return sendingCustomerName;
    }


    @Override
    public String toString() {
        return "Order{" +
                "orderId='" + orderId + '\'' +
                ", brand='" + brand + '\'' +
                ", numberOfBottles=" + numberOfBottles +
                ", sendingCustomerName='" + sendingCustomerName + '\'' +
                '}';
    }
}
