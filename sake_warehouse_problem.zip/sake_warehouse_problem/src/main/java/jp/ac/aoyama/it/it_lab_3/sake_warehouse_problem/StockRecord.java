package jp.ac.aoyama.it.it_lab_3.sake_warehouse_problem;

public class StockRecord {
    private String liquorName;
    private int quantity;

    public StockRecord(String liquorName, int quantity) {
        this.liquorName = liquorName;
        this.quantity = quantity;
    }

    public String getLiquorName() {
        return liquorName;
    }

    // テストファイル互換用にgetBrandメソッドを追加
    public String getBrand() {
        return liquorName;
    }

    public int getQuantity() {
        return quantity;
    }

    // テストファイル互換用にgetNumberOfBottlesメソッドを追加
    public int getNumberOfBottles() {
        return quantity;
    }

    public void reduceQuantity(int amount) {
        quantity = Math.max(0, quantity - amount);
    }
    public void increaseQuantity(int amount) {
        quantity += amount;
    }

    @Override
    public String toString() {
        return "StockRecord{liquorName='" + liquorName + "', quantity=" + quantity + '}';
    }
}
