//15822065 助友剛

package jp.ac.aoyama.it.it_lab_3.sake_warehouse_problem;

import java.util.ArrayList;
import java.util.List;
public class Customer {
    // 顧客名リストの定数
    public static final List<String> CUSTOMER_NAME_LIST = List.of(
            "A-sake-shop", "B-sake-shop", "C-sake-shop",
            "D-sake-shop", "E-sake-shop", "F-sake-shop",
            "G-sake-shop", "H-sake-shop", "I-sake-shop",
            "J-sake-shop", "K-sake-shop"
    );

    private String customerName; // 顧客名
    private List<Order> orderList; // 顧客の注文リスト
    private LiquorSalesCompany supplier; // 供給者を追加

    // 新しいコンストラクタを追加
    public Customer(String customerName, LiquorSalesCompany supplier) {
        if (!CUSTOMER_NAME_LIST.contains(customerName)) {
            throw new IllegalArgumentException("顧客名が無効です");
        }
        this.customerName = customerName;
        this.supplier = supplier; // 供給者の初期化
        this.orderList = new ArrayList<>();
    }

    // createOrderメソッド：注文を生成してリストに追加
    public void createOrder(String orderId, String brand, int numOfBottles) {
        Order newOrder = new Order(orderId, brand, numOfBottles, customerName);
        orderList.add(newOrder);
    }

    // orderメソッド：リスト内の注文を受付係にリクエスト
    public void order() {
        for (Order order : orderList) {
            // WarehouseClerkのmakeRequestメソッドを呼び出して酒を注文
            System.out.println("Order processed for: " + order.toString());
        }
    }

    // 顧客名を取得
    public String getCustomerName() {
        return customerName;
    }

    // 注文リストを取得
    public List<Order> getOrderList() {
        return orderList;
    }
    public int getNumberOfOrders() {
        return orderList.size(); // 注文リストのサイズを返す
    }
}
