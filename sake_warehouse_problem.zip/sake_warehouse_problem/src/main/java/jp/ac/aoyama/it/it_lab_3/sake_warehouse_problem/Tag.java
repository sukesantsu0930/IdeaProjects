package jp.ac.aoyama.it.it_lab_3.sake_warehouse_problem;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Tag {
    private int containerId;
    private Date broughtDate;
    private List<StockRecord> stockRecords;
    private Liquor liquor;

    public Tag(Liquor liquor, int initialQuantity) {
        this.liquor = liquor;
        this.stockRecords = new ArrayList<>();
        this.broughtDate = new Date();
        addStock(initialQuantity);
    }

    public Liquor getLiquor() {
        return liquor;
    }

    public void addStock(int numOfBottles) {
        for (StockRecord record : stockRecords) {
            if (record.getLiquorName().equals(liquor.getBrand())) {
                record.increaseQuantity(numOfBottles);
                return;
            }
        }
        stockRecords.add(new StockRecord(liquor.getBrand(), numOfBottles));
    }

    public int getNumberOfBottles() {
        int total = 0;
        for (StockRecord record : stockRecords) {
            total += record.getQuantity();
        }
        return total;
    }


    public int takeLiquor(String liquorName, int quantity) {
        int taken = 0;
        for (StockRecord record : stockRecords) {
            if (record.getLiquorName().equals(liquorName)) {
                int available = record.getQuantity();
                if (available >= quantity) {
                    record.reduceQuantity(quantity);
                    taken += quantity;
                    break; // Enough stock has been taken, exit loop
                } else {
                    taken += available;
                    record.reduceQuantity(available);
                    // If stock is exhausted, continue to next record
                }
            }
        }
        stockRecords.removeIf(record -> record.getQuantity() == 0);
        return taken;
    }



    // 追加：在庫記録リストを取得するためのメソッド
    public List<StockRecord> getStockRecordList() {
        return stockRecords;
    }

    public String getBroughtDate() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        return sdf.format(broughtDate);
    }

    @Override
    public String toString() {
        return "Tag{containerId=" + containerId + ", broughtDate=" + getBroughtDate() +
                ", stockRecords=" + stockRecords + '}';
    }
}
