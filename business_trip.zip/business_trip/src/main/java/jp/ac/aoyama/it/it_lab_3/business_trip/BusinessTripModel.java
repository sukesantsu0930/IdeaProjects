package jp.ac.aoyama.it.it_lab_3.business_trip;

public class BusinessTripModel {
    private String name;
    private String jobTitle;
    private String travelCategory;
    private int dailyAllowance;
    private int travelDays;
    private int travelHours;
    private String location;
    private String cityType;
    private int accommodationFee;
    private int numberOfNights;

    public BusinessTripModel(String name,String travelCategory,int travelDays){
        this.name=name;
        this.travelCategory=travelCategory;
        this.travelDays=travelDays;
        dailyAllowance=-1;
        travelHours=-1;
        accommodationFee=-1;
        numberOfNights=-1;
    }

    public int getAccommodationFee() {
        return accommodationFee;
    }

    public int getNumberOfNights() {
        return numberOfNights;
    }

    public void setAccommodationFee(int accommodationFee) {
        this.accommodationFee = accommodationFee;
    }

    public void setNumberOfNights(int numberOfNights) {
        this.numberOfNights = numberOfNights;
    }





    public void setName(String name) {
        this.name = name;
    }

    public void setJobTitle(String jobTitle) {
        this.jobTitle = jobTitle;
    }

    public void setTravelCategory(String travelCategory) {
        this.travelCategory = travelCategory;
    }

    public void setDailyAllowance(int dailyAllowance) {
        this.dailyAllowance = dailyAllowance;
    }

    public void setTravelDays(int travelDays) {
        this.travelDays = travelDays;
    }

    public void setTravelHours(int travelHours) {
        this.travelHours = travelHours;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public void setCityType(String cityType) {
        this.cityType = cityType;
    }



    public String getName() {
        return name;
    }

    public String getJobTitle() {
        return jobTitle;
    }

    public String getTravelCategory() {
        return travelCategory;
    }

    public int getDailyAllowance() {
        return dailyAllowance;
    }

    public int getTravelDays() {
        return travelDays;
    }

    public int getTravelHours() {
        return travelHours;
    }

    public String getLocation() {
        return location;
    }

    public String getCityType() {
        return cityType;
    }


}
